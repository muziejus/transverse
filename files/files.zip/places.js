var places = [
  {
    "type": "Feature",
    "geometry": {
      "type": "Point",
      "coordinates": [-83.037,42.334]
    },
    "properties": {
      "name": "Hastings Street",
      "instances": 2
    }
  },
  {
    "type": "Feature",
    "geometry": {
      "type": "Point",
      "coordinates": [-73.946,40.81]
    },
    "properties": {
      "name": "Lenox Avenue",
      "instances": 2
    }
  },
  {
    "type": "Feature",
    "geometry": {
      "type": "Point",
      "coordinates": [-94.5625,39.091]
    },
    "properties": {
      "name": "18th & Vine",
      "instances": 1
    }
  },
  {
    "type": "Feature",
    "geometry": {
      "type": "Point",
      "coordinates": [-84.524, 39.1]
    },
    "properties": {
      "name": "5th & Mound",
      "instances": 1
    }
  },
  {
    "type": "Feature",
    "geometry": {
      "type": "Point",
      "coordinates": [-90.072,29.956]
    },
    "properties": {
      "name": "Rampart",
      "instances": 1
    }
  }
];
